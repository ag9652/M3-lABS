package com.capg.service;

import com.capg.entities.AuthorDetails;

public interface AuthorService {
	
	public void addAuthor(AuthorDetails a);
	public void removeAuthor(int a);
	public void updateAuthor(AuthorDetails a);
	public AuthorDetails findAuthor(int aid);
	
}
